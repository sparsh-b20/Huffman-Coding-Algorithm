# Huffman Coding Project
The semester-long project to implement the *Huffman Coding*, 
a lossless data compression algorithm, using data structures like trees and linked lists in `C++`.
